docker push your_image_name:tag
