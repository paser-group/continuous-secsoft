kubectl apply -f server-deployment.yaml
