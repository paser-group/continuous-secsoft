python script.py input.md
