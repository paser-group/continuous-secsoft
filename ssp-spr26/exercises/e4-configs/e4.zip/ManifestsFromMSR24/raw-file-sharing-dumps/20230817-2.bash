docker build -t your_image_name:tag .
