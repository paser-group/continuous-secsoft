kubectl scale deployment server-deployment --replicas=5
