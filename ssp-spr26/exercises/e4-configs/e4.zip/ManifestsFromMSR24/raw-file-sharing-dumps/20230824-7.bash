kubectl apply -f server-service.yaml
