---
name: Idea
about: Ideas, feature requests, and wishes
labels: idea
---

### What should we add or change to make your life better?

### Why is this important to you?