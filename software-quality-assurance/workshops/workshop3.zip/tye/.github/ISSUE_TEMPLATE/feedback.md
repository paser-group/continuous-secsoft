---
name: Feedback
about: Tell us what you think!
labels: feedback
---

### Some details

**How many services are in your application? (including things like databases, redis):**

- [ ] 1-2
- [ ] 3-5
- [ ] 6-10
- [ ] 10+

**What did you use tye for?**

- [ ] Local development
- [ ] Deployment

**How is your code organized?**

- [ ] One service per repo
- [ ] Many services in one big repo
- [ ] Other (please explain)

### What did you think of tye?
