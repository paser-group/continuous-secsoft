# Traefik

The helm chart was forked from https://github.com/helm/charts/tree/master/stable/traefik. See this url for configuration options.