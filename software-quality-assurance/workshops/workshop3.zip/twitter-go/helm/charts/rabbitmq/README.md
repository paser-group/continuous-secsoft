# Rabbitmq

The helm chart was forked from https://github.com/helm/charts/tree/master/stable/rabbitmq. See this url for configuration options.