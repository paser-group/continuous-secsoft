# Cassandra

The helm chart was forked from https://github.com/helm/charts/tree/master/incubator/cassandra. See this url for configuration options. Additionally, https://kubernetes.io/docs/tutorials/stateful-application/cassandra/ serves as a lower level resource for deploying and verifying cassandra on a kubernetes cluster.