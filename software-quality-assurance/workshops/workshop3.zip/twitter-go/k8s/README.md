# k8s

This folder contains a few yaml files used in `scripts/setup-k8s.sh` to configure a kubernetes cluster with the appropriate roles for tiller, which is a piece of software
required by helm on the cluster for managing releases.